package com.retrofit.vanson;

public class Define {

    public static final String BASE_URL = "https://api.openweathermap.org/data/2.5/";
    public static final String API_KEY = "7e5dcacfa46a733e084fd65210c78e96";
    public static final String ICON_URL = "http://openweathermap.org/img/w/";
}
