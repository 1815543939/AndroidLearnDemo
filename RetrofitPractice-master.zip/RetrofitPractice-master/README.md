# RetrofitPractice
Practice retrofit with https://openweathermap.org/
