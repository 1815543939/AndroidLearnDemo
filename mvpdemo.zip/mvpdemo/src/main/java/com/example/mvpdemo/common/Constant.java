package com.example.mvpdemo.common;

/**
 * Created by Administrator on 2016/4/24.
 */
public interface Constant {
    String BASE_URL = "http://www.weather.com.cn/data/sk/";
}
