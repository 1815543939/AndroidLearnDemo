package com.example.mvpdemo.model.entity;

/**
 * Created by Administrator on 2016/4/24.
 */
public class Weather {
}
