# Silent Install

This project targets to realize the following function:Control the client's apps by edit configure file in server,
including install some apps,uninstall some apps and upgrade some apps. 

### Control Process
1.Download control info from server;<br>
2.Analysis control info<br>
3.Execute control operation<br>

#### Control Info
The info kept in json files,an actual demo is [control_1.json](https://github.com/seek4/SilentInstall_AndroidTV/blob/master/control_1.json)<br>

### Note
The app must obtain the system authority to realize silent-install. 


#### contact me
E-mail:haoyunyangtong@gmail.com
