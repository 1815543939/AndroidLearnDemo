package com.changhong.appcontrol.model;

public class UninsApp {
	public String appName;
	public String packageName;
	public int uninsType;
}
