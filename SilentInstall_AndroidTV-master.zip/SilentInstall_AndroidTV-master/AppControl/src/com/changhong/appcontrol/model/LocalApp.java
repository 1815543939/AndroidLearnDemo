package com.changhong.appcontrol.model;

public class LocalApp {
	public String packageName;
	public String appName;
	public String version;
}
