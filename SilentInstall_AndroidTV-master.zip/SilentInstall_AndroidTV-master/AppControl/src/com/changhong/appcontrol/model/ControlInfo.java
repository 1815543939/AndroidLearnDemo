package com.changhong.appcontrol.model;

import java.util.List;

public class ControlInfo {
	public String version;
	public List<InstallApp> installList;
	public List<UninsApp> uninsList;
}
