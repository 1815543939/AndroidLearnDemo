package com.changhong.appcontrol.transfer;

public interface TransferCallBack {
	public void transferFinish(String controlJson);
}
