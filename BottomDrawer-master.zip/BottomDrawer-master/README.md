# BottomDrawer
底部抽屉效果，上下方向抽屉控件，滑动或点击控制弹出收回，BottomDrawer



<img src='images/image1.gif' height='500px'/>

