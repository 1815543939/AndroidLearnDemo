package android.content.pm;

public class ManifestDigest {

}
