package android.content.pm;

import android.app.Application;

public class MarketApplication extends Application {

}
